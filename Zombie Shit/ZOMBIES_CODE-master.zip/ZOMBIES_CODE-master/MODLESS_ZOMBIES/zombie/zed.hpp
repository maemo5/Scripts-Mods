class CfgSounds
{
	sounds[] = {};
	class zomb1
	{
		name = "zomb1";
		sound[] = {"\zombie\sounds\zomb1.ogg", 1, 1};
		titles[] = {};
	};
	class zomb2
	{
		name = "zomb2";
		sound[] = {"\zombie\sounds\zomb2.ogg", 1, 1};
		titles[] = {};
	};
	class zomb3
	{
		name = "zomb3";
		sound[] = {"\zombie\sounds\zomb3.ogg", 1, 1};
		titles[] = {};
	};
};