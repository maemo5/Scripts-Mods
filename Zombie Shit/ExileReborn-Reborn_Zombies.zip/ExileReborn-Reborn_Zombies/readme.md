#Installation

v 0.1

Install EXILE on your server as per normal.

1. Replace your Exile."MapName" with Exile.Altis or Esseker, from this repo
2. Copy the contents of core_client_files inside your Exile.MapName folder
3. Replace your replace the contents of your @ExileServer\addons with the contents from this repo - You will need to PBO each folder inside @ExileServer\addons respectivley.
4. Replace your battle eye filters
5. Navigate to @ExileServer\addons\JohnOs_events\addons\Events\events_config.sqf line 10 - Change the UID to a valid UID that exists in the account table
6. Profit.

This version requires Zombies and Demons.
This version supports ESSEKER and ALTIS.

For more info on features head to www.exilereborn.com