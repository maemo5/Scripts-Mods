/*

*/

class spawnAIrequest
{
    module = "JohnO";
    parameters[] = {"STRING","SCALAR","SCALAR","SCALAR","SCALAR","BOOLEAN","BOOLEAN","SCALAR"};
};

class spawnHuntersOnTarget
{
    module = "JohnO";
    parameters[] = {"OBJECT"};
};

class spawnZombieNearTarget
{
    module = "JohnO";
    parameters[] = {"ARRAY"};
};
class hideObjectGlobal
{
    module = "JohnO";
    parameters[] = {"STRING","BOOL"};
};
class spawnSurvivorNearTarget
{
    module = "JohnO";
    parameters[] = {"ARRAY"};
};
class updateRespectAndTabs
{
    module = "JohnO";
    parameters[] = {"SCALAR","SCALAR","BOOL"};
};