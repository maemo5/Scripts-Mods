class crafted_junkMetal: Exile_AbstractCraftingRecipe
{
	name = "Junk Metal";
	pictureItem = "Exile_Item_JunkMetal";
	requiresFire = 1;
	returnedItems[] =
	{
		{1, "Exile_Item_JunkMetal"}
	};
	components[] = 
	{
		{4, "Exile_Item_Can_Empty"}
	};
};