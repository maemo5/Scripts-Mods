class crafted_Vishpirin: Exile_AbstractCraftingRecipe
{
	name = "Vishpirin";
	pictureItem = "Exile_Item_Vishpirin";
	returnedItems[] =
	{
		{1, "Exile_Item_Vishpirin"}
	};
	tools[] =
	{
		"Exile_Item_Can_Empty"
	};
	components[] = 
	{
		{1, "Exile_Item_SeedAstics"},
		{1, "Exile_Item_PlasticBottleFreshWater"},
		{1, "Exile_Item_EnergyDrink"}
	};
};