###May 7th, 2016
**[FIXED]** action does not re-appear after respawn
