##ArmA3_exile_SimpleAmmoRepacker
###Simple but fancy ammo repack menu for ArmA 3 Exile Mod
<br />
######HOW TO DOWNLOAD
Click the "Download ZIP" button<br />
######INSTALLATION GUIDE
```
Exile.MapName\init.sqf (contents) >> MPmissions\Exile.*nameOfMap*\init.sqf
Exile.MapName\description.ext (contents) >> MPmissions\Exile.*nameOfMap*\description.ext
Exile.MapName\scarCODE >> MPmissions\Exile.*nameOfMap*\
```
