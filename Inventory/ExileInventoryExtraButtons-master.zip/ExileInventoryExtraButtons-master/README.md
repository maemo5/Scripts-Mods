# ExileInventoryExtraButtons
Two Simple buttons to Inventory screen

Make an edit to your CfgExileCustomCode to include the onInventoryOpened file
Overwrite the file and edit the buttons to your liking!

Enjoy!
