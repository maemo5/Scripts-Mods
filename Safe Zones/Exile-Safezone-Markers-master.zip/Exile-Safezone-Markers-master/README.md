# Exile-Safezone-Markers

## *Install Instructions*
1. Click [**Clone or Download**](https://github.com/dtavana/Exile-Safezone-Markers/archive/master.zip) on the Repository Page
2. Extract the downloaded ZIP and open it
3. Create the folder custom\SafezoneMarkers in your mission root
4. Add the following to the bottom of your initServer
`call compile preprocessFileLineNumbers "custom\SafezoneMarkers\initSafezoneMarkers.sqf";`
5. Configure the settings in `initSafezoneMarkers` to your liking

> Credits to @BigEgg17 for the math behind creating a circle of markers