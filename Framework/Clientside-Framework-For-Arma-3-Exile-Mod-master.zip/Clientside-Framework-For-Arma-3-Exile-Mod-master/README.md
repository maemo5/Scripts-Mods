## Clientside-Framework-For-Arma-3-Exile-Mod
#####by [midgetgrimm]

Simple clientside framework that you can drag and drop scripts and functions into. 

I made it for Exile Mod but really applies to any Arma

Just add your file, define it in the custom_code.h

call it via exsys_fnc_scriptName

You can use call or spawn - look them up, what if you need execVM "Oh No"

