class exile_client_system
{
	tag = "exsys";
	class system
	{
		file = "system";
	};
	class player
	{
		file = "system\player";
		class keybinds {};
	};
	class network
	{
		file = "system\network";
		class quickStats {};
	};
};