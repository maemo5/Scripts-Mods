Part of Arma Containers And Decorations

Mission provided in this folder will help you browse models and extract them as
container or decoration vehicles.

This mission is not user friendly in any way, it is made for internal use,
in order to use it you will need certain level of sqf scripting knowledge,
and alot of manual tweaking of scripts.

Also, you will need KK`s makeFile.dll v1.5 to be able to dump strings to file.

It is possible to use composition tool with this mission.
https://forums.bistudio.com/topic/186056-composition-tool-eden-editor-plugin/