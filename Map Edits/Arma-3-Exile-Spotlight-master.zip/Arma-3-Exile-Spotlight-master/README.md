# Arma-3-Exile-Spotlight
This is A Modded Spotlight Of The Original Modded BIS Spotlight by ThatGuyHats Original Creator AKP. 
I only do is Fix The Server Key TO Be Added And Fully Working On Exile Servers.
Big Thanks To AKP for this creation and his permission to release this port and others.
