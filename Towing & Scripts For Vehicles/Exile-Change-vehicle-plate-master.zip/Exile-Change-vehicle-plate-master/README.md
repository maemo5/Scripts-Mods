# Exile-Change-vehicle-plate

ATTENTION: THIS SCRIPT REQUIRED ARMA 3 1.82! DO NOT USE THAT UNTILL RELEASE 1.82 PATCH! Thanks!

This is first upload release, if scripts have mistakes, please, post problems here, in this topic! http://www.exilemod.com/topic/26040-change-vehicle-plate/
Checked on ArmA Vanilla vehicles, 90% vehicles supported successfuly! some 3rd party vehicles may not be supported.:(