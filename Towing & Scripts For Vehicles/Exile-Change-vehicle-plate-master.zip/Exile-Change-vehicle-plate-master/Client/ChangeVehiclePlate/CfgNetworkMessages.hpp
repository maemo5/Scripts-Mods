class CfgNetworkMessages
{
	class changeVehiclePlate
	{
		module = "object_vehicle";
		parameters[]=
		{
			"STRING",
			"STRING"
		};
	};
	class setPlateNumber
	{
		module = "object_vehicle";
		parameters[]=
		{
			"STRING",
			"STRING"
		};
	};
};