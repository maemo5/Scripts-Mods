# Exile_Igiload

Igiload with Config for Exilemod.com

Installation:

1. Copy Folder to your Missionfile
2. Open Init.sqf in the root Folder of the Missionfile 
3. Add this to it: [] = execVM "IgiLoad\IgiLoadInit.sqf";
4. Overwrite ExileClient_object_player_event_onEnterSafezon.sqf in the Config.cpp in the Missionfile 

