//Bones Custom Vehicle Repairs

class Repair: ExileAbstractAction
{
	title = "Repair/Salvage";
	condition = "true";
	action = "_this call Bones_fnc_salvageAndRepairMenu";
};


// Bones Custom Air Repairs
class Repair: ExileAbstractAction
{
	title = "Repair/Salvage";
	condition = "true";
	action = "_this call Bones_fnc_salvageAndRepairMenu";
};

