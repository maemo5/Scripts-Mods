# Interior_Lock-Master
This adds the ability to lock and unlock vehicles from the inside with either scroll wheel functions or the Exile default hot key to lock and unlock objects.

See Installation Instruction
