class CfgVemfrScripts
   {
      checkLoot = "a3_vemf_reloaded\sqf\checkLoot.sqf";
      giveFire = "a3_vemf_reloaded\sqf\giveFire.sqf";
      handleKillCleanup = "a3_vemf_reloaded\sqf\handleKillCleanup.sqf";
      handleKillReward = "a3_vemf_reloaded\sqf\handleKillReward.sqf";
      killedMonitor = "a3_vemf_reloaded\sqf\killedMonitor.sqf";
      loadLoot = "a3_vemf_reloaded\sqf\loadLoot.sqf";
      loadInv = "a3_vemf_reloaded\sqf\loadInv.sqf";
      log = "a3_vemf_reloaded\sqf\log.sqf";
      missionTimer = "a3_vemf_reloaded\sqf\missionTimer.sqf";
      notificationToClient = "a3_vemf_reloaded\sqf\notificationToClient.sqf";
      overrides = "a3_vemf_reloaded\sqf\overrides.sqf";
      REMOTEguard = "a3_vemf_reloaded\sqf\REMOTEguard.sqf";
      sayKilled = "a3_vemf_reloaded\sqf\sayKilled.sqf";
      setGroupOwner = "a3_vemf_reloaded\sqf\setGroupOwner.sqf";
      signAI = "a3_vemf_reloaded\sqf\signAI.sqf";
      spawnStaticAI = "a3_vemf_reloaded\sqf\spawnStaticAI.sqf";
      systemChatToClient = "a3_vemf_reloaded\sqf\systemChatToClient.sqf";
      warningToClient = "a3_vemf_reloaded\sqf\warningToClient.sqf";
   };
