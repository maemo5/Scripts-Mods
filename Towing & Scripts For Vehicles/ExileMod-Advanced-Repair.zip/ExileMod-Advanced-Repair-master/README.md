# ExileMod-Advanced-Repair
Complex repair script for ExileMod with a selection menu that allows:</br>
 a.   Repair and salvage of engine and wheels for vehicles</br>
 b.   Repair and salvage of engine, tail rotor and main rotors for helo's.</br>
 c.   Repair of vehicle body.</br>
 d.   Repair entire Vehicle.</br>

To-do list:</br>
 a.   Include need for wheels for repairing entire vehicle, and repair only as many wheels as what the player currently has in inventory.</br>

Installation:

Refer to Install instructions contained within the file.

Credit to John for his original idea and work, that portions of this script are based on (http://www.exilemod.com/profile/38-john/)
