Overwrite ExileClient_object_player_event_onEnterSafezon.sqf in the Config.cpp in the Missionfile 


