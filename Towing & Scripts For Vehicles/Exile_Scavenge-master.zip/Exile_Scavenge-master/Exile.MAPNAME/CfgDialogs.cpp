/*
    Master UI Resource File
*/

class RscTitles
{	
	class Default
	{
		idd = -1;
		fadein = 0;
		fadeout = 0;
		duration = 0;
	};
	// Scavenge system
	#include "dialogs\ExileScavengeUI.hpp"
};