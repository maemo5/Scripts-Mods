name = "UAV Hacker";
author = "Sasha";
overview = "Allows all units to use the Hack UAV action.";