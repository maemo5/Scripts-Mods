class CfgPatches
{
  class hackerSchool {
    units[] = {};
    weapons[] = {};
    requiredVersion = 1.26;
    requiredAddons[] = {};
  };
};

class CfgVehicles
{
  class All {
    uavHacker = 1;
  };
};