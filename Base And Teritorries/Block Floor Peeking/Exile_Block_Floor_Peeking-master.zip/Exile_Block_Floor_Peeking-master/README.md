# Exile_Block_Floor_Peeking
Blocks floor peeking in Arma 3 Exile
https://www.youtube.com/watch?v=yG7n4ihrUwE
