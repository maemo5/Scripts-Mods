//Add to custom code
class CfgExileCustomCode
{
	ExileClient_object_player_initialize = "addons\fixes\ExileClient_object_player_initialize.sqf";
	ExileClient_object_player_stats_update = "addons\fixes\ExileClient_object_player_stats_update.sqf";
};