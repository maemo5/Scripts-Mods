# PersistentTreeLogging
Tree Logging Persistent for Exile.

# -not- Todo
-Make tree's regrow realistic by setting a status code to the entry after a "" mount of days. 
- Sorta Done

-From that status code spawn in small bush, medium bush or big bush/small tree.
- Sorta Same

-Give option to "regrowing" tree to "pull out" so its gone again and reset status code.
- keeping this on my own server. 

-Fuck whut? 
- Reduced spam and extdb calls.
- Performance update sorta
## Configuration

- 1: Add inside your mission config.cpp at the cfgcustomcode ExileServer_object_tree_network_chopTreeRequest and use the file provided inside MpMission/overwrites.

- 2: Add the additions from Exile.ini to your Exile.ini.

- 3: Import the Tree.sql inside your MySQL database. 

- 4: Drag the Server Addon to your ExileServer Addons folder and profit.

## License
Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0)
## Credits
Original code base by CoftSock.

## Donations

Fuck you and you're donations, send them to Exile.

http://www.exilemod.com/donate/make-donation/


You still reading? Fine,, Questions and other BS, or if you really wanna donate me a cup of coffee https://discord.united-gamers.online
