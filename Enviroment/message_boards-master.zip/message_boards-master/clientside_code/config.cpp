class CfgExileNGMessageBoards
{
	positions[] = {{3628.18, 3212.83, 0},{8066.361, 9722.938, 0}};
};