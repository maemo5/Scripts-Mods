# XM8BaseLocator
Test the spot you are at to see if you can build there


Plop and drop, all needed info is inside the files included, replace what app you would like.

Image file in images folder and sqf in custom folder
