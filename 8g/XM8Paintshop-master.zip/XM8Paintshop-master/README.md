# XM8Paintshop
Version 1 Release, Paintshop partayy

1. [Client] Paste the XM8Paintshop folder in your xm8apps folder

2. [Client] Update your xm8apps_init.sqf with provided information and picture.

3. [Client] Edit Prices and custom textures.. Enjoy!
