# XM8MapMarkers
Map markers for players that stay over restart

INSTALL:

1. Add the app to your custom app 1-11

2. Place the image inside your images folder and create a custom folder

3. Place the XM8MapMarkers.sqf inside your custom folder.

4. Optional, edit the icon of the marker - see inside .sqf for instructions.

5. Post on the thread with any specific questions!
