class CfgNotifications {

	class RespectReceived {
		description = "<t size='1' font='puristaMedium' align='left'>%1<img image='\exile_assets\texture\ui\fail_ca.paa' size='1' shadow='true' /> received from %2</t>";
		title = "Respect Transfered!";
		iconPicture = "\exile_assets\texture\ui\success_ca.paa";
		iconText = "";
		color[] = {0.700000, 0.930000, 0, 1};
		duration = 3;
		priority = 0;
		difficulty[] = {};
	};

	class RespectHijacked {
		description = "<t size='1' font='puristaMedium' align='left'>%1<img image='\exile_assets\texture\ui\fail_ca.paa' size='1' shadow='true' /> Hijacked from %2</t>";
		title = "Respect Hijacked!!";
		iconPicture = "\exile_assets\texture\ui\success_ca.paa";
		iconText = "";
		color[] = {0.700000, 0.930000, 0, 1};
		duration = 3;
		priority = 0;
		difficulty[] = {};
	};

};
