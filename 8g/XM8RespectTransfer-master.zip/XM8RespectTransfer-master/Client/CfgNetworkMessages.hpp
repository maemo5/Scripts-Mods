class CfgNetworkMessages {
	class transferRespectRequest {
		module = "system_trading";
		parameters[] = {"STRING", "STRING"};
	};

	class respectTransferRequest {
		module = "system_trading";
		parameters[] = {"STRING", "STRING"};
	};

	class respectReceivedRequest {
		module = "system_trading";
		parameters[] = {"STRING", "STRING"};
	};

	class respectHijackedRequest {
		module = "system_trading";
		parameters[] = {"STRING", "STRING"};
	};
};
