# 8GNetworkGroups
Group Members appear the same color as player on XM8

Include the overwrite inside of the included config.cpp

Place the scripts folder and file included in your mission folder or change filepath

And we GOOD!

