#Core  
## Instructions:   

### v0.7.7 
* Replace "mpmissions\Exile.<map>\ExAdClient\Core"

### v0.7.6 
* Replace or merge "mpmissions\Exile.<map>\ExAdClient\Core\customize.sqf"
* Replace or merge "mpmissions\Exile.<map>\stringtable.xml"
* Replace "mpmissions\Exile.<map>\ExAdClient\Core" - Big update
* Replace and pack "@ExileServer\addons\exad_core"
 
### v0.7.3 
* Replace "mpmissions\Exile.<map>\ExAdClient\Core\postInit.sqf"

### v0.7.0  
* Replace "ExAdClient\Core\customize.sqf"
  
### v0.5.1  
* Description.ext was wrongly configured fixed ("CfgRemoteExec" >> "Functions")
```js
	class ExAdServer_fnc_clientRequest { allowedTargets=2; };
```  

###  v0.5.1  
* Add "ExAdClient\Core\Img"   
 
### v0.5.0  
* Full installation