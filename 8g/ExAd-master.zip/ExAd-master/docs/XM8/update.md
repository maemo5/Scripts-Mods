#XM8  
## Instructions:   
 
### 160603 . v0.7.7  
* Full installation
