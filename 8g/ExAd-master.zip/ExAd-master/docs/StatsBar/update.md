#StatsBar 
## Instructions:   
 
### 160801 . v0.8.0  
* Full installation
