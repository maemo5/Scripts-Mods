class CfgExileCustomCode 
{
    ExileClient_gui_virtualGarageDialog_event_onLocationChanged = "ExileClient_gui_virtualGarageDialog_event_onLocationChanged.sqf";
};
