class CfgRemoteExec
{
	class Functions
	{
		mode = 1;
		jip = 0;
		//ADD to your CfgRemoteExec.hpp
		class ExileServer_xm8apps_scans_network_request { allowedTargets=2; };
	};
	class Commands
	{
		mode=0;
		jip=0;
	};
};