# Sphub ExileCLO

### What is this?
This server side addon allows you to edit any aspect of the Exile UI.

## How do I use this?
1. You need to de-bin your exile.cpp from the exile_client.pbo
2. Find the UI element Id and its namespace (In the example we are using the Xm8 Namespace to edit the front page)
3. Look at the example and the bi wiki for how to edit ui

## Issues
--- If you are experiencing issues your server may be preventing the addition of threads. Please check your remoteexec setup in
your mission file (If Infistar works this should work too!)

If you have questions about this (I Know yall will as this documentation is shit!) Please either create a git issue or a reply on the forums to this topic!
