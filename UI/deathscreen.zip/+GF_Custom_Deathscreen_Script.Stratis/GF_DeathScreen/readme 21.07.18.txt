


//________________  Author : [GR]GEORGE F ___________ 21.07.18 _____________

/*
________________ GF Custom Deathscreen Script ________________

https://forums.bistudio.com/forums/topic/205897-custom-deathscreen-script/

Please keep the Credits or add them to your Diary

https://community.bistudio.com/wiki/SQF_syntax
Don't try to open this with the simple notepad.
For everything that is with comment  //  in front  or between /* 
means that it is disabled , so there is no need to delete the extra lines. 

You can open this ex:
with notepad++
https://notepad-plus-plus.org/

and also use the extra pluggins
(this way will be better , it will give also some certain colours to be able to detect ex. problems )
http://www.armaholic.com/page.php?id=8680

or use any other program for editing .

For the Compilation List of my GF Scripts , you can search in:
https://forums.bohemia.net/forums/topic/215850-compilation-list-of-my-gf-scripts/
*/


Version 1.2 


Script Author :
 
by GEORGE FLOROS [GR]




Description:
Adding an image of blood and sound when killed to spice it a little bit.
You are free to do anything but i would like to give me Credits for this!
Simple and easy to use and adapt .
Have Fun!

Installation / Usage:
Place the files in your mission . There is everything included in the description.ext, to copy paste from.


Credits & Thanks:
Thanks to All script contributors
Thanks to everyone who tries to do the best for this game!


Changelog:

v1.2
Changed the name of all the scripts , starting now with GF . 

v1.1
fixed the name cause of misspell ! ( Deathscreen )

v1.0


more info to :

https://forums.bistudio.com/forums/topic/205897-custom-deathscreen-script/
http://www.armaholic.com/page.php?id=32868


Disclaimer :

I take no responsibility for (im)possible damage to your game/system that may be caused by installation of this Mission.

ALL CONTENT IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND. I MAKE NO WARRANTIES, EXPRESS OR IMPLIED, 
THAT THEY ARE FREE OF ERROR, OR ARE CONSISTENT WITH ANY PARTICULAR STANDARD OF MERCHANTABILITY, OR THAT 
THEY WILL MEET YOUR REQUIREMENTS FOR ANY PARTICULAR APPLICATION. USE AT YOUR OWN RISK. THE AUTHOR AND 
PUBLISHER DISCLAIM ALL LIABILITY FOR DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES RESULTING FROM YOUR 
USE OF THE PROGRAMS.  




