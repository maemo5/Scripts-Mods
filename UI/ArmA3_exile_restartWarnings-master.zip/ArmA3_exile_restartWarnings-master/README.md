#ArmA3_exile_restartWarnings
###client-side automated restart warnings for ArmA 3 Exile Mod
<br />
######HOW TO DOWNLOAD
Clone or download >> "Download ZIP" button <br />
######INSTALLATION GUIDE
```
Exile.MapName\init.sqf (contents) >> MPmissions\Exile.*nameOfMap*\init.sqf
Exile.MapName\description.ext (contents) >> MPmissions\Exile.*nameOfMap*\description.ext
Exile.MapName\scarCODE >> MPmissions\Exile.*nameOfMap*\
```
######CONFIGURATION GUIDE
Have a look in:
```
Exile.MapName\scarCODE\restartWarnings\config.cpp
```
