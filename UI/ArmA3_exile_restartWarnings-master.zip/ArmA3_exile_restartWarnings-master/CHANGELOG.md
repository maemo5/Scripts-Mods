#####1st release: June 19th, 2016

####Update July 2nd, 2016
**[FIXED]** script error <br />
<br />

####Update June 21st, 2016
**[FIXED]** error missing ; <br />
<br />

####Update June 20th, 2016
**[FIXED]** "Do Restart Warning" action still present <br />
**[FIXED]** systemChat debug information still present <br />
<br />
