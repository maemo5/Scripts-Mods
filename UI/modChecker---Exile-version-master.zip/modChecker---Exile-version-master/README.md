This scripts check the mods loaded by the client. If one mod is not loaded, automate POP UP's the player on spawn to warn, with costumizable links to community guides.
You can define each mod as “required” or “doesn’t required”. If the mod is required, MOD checker warns the player, and when this closes the dialog are silent kicked from the game.

If the mod is not required, Mod checker warns the player, but the player can still on the server.
If no errors are generated, mod checker runs in silent without popup

https://i.imgur.com/yseE9pL.png

Please follow the next install instructions and read all scripts and comments
http://www.exilemod.com/topic/18743-mod-checker/

// * This project is licensed under Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0) 
// * https://creativecommons.org/licenses/by-sa/4.0/

Feel free to modify or adapt my work.

This project, contains some code from Repentz Advanced Rulez http://www.exilemod.com/topic/10375-advanced-server-rules-for-xm8/

