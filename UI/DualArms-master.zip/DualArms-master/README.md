# DualArms
Files for DualArms mod

Please see the following links to learn more about this repo:

http://steamcommunity.com/sharedfiles/filedetails/?id=1334412770

http://www.exilemod.com/topic/25999-dualarms-two-primary-weapons/
