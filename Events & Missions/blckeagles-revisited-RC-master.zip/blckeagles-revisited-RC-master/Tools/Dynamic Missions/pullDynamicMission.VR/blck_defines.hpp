/*
	for ghostridergaming
	By Ghostrider [GRG]
	Copyright 2016
	
	--------------------------
	License
	--------------------------
	All the code and information provided here is provided under an Attribution Non-Commercial ShareAlike 4.0 Commons License.

	http://creativecommons.org/licenses/by-nc-sa/4.0/	
*/

#define GRGserver
#define useAPEX 
//#define useDynamicSimulation
#define blck_debugMode
#define blck_triggerLoopCompleteTime 40*60
//#define blck_milServer
//#define GRG_TestServer
//#define blck_useCUP
//#define blck_useRHS

////////////////////////////
//  Do not touch anything below this line
///////////////////////////
#define onFoot 1
#define inVehicle 2

//  defines for static group spawners
#define staticPatrolTriggerRange 2000
#define groupParameters 0
#define patrolGroup 1
#define groupSpawned 2
#define timesSpawned 3
#define respawnAt 4


