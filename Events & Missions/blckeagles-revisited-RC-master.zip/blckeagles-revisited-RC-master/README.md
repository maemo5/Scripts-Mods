Blckegls mission system 

Included is an updated version of blckeagls mission system. This began as an effort to fix bugs in and upgrade version 2.0.2 as updated by Narines and has now evolved to a complete reworking of almost all code. 


* Installation: Please refer to Installation.txt for a detailed description of installation and what you need to add to BE filters.
* Loading crates on SDV at underwater missions. For epoch, please feel free to use the modified IgiLoad on my github.
  For exile users, modify your misionfil.pbo/config.sys as described below.
  http://www.exilemod.com/topic/17352-bigfoots-shipwrecks/
  infiSTAR Users: you may need to whitelist _MainMarker depending on your settings.

* Adjusting Settings: You can adjust many features that include numbers of AI, AI Skills, AI Loadouts with weapons and consumables, and what is added to the crate. See AdjustingSettings.txt and the configuration files for more details.
	
* Credits
	Epoch Mod developer team.
	blckeagls - Mission system 2.0.2
	Grahame for suggestions for new features, coding improvements and updates to the Epoch-specific Configs.
	Narines - bug fixes and improvements.
	Bill (DBD Clan) for example compositions.
	cyncrwler, Grahamme and many others for help with troubleshooting and testing
	Brian Soanes for performance fixes and general guidance.
	
* Additional Credits include authors of other missions systems who's work influenced this update. 
	I have indicated as best as possible where work was directly derived from their contributions.:
	KiloSwiss (SEM)
	Hogscrapper (HC missions for A3)
	the Vampire (DZMS and VEMF)
	The FUCHS (EMS)
	lazylink (the original mission system)
	Matt11 (Wicked AI) Updates:
	Face (A3EAI/A3XAI)
	
* Compatability
	Works well with VEMF, SEM, and A3AI all running on the same server.
	
* Please see the change log for a full listing of the most current changes.

--------------------------
License
--------------------------
All the code and information provided here is provided under an Attribution Non-Commercial ShareAlike 4.0 Commons License.

http://creativecommons.org/licenses/by-nc-sa/4.0/
