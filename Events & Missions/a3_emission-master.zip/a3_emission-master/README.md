Arma 3 Emission/Blowout Script [a3_emission]
=============
A S.T.A.L.K.E.R. inspired blowout/emission script for use in Exile or custom Co-Op missions, this is derived work based on the original scripts for Arma 2: Namalsk Crisis made by Nightstalkers for the custom mission addons and DayZ: Epoch.
There have been major revisions and updates by Major Khunt and FallingSheep from the Exilemod.com forums to adapt the script so it is functional on Arma 3 and in particular, Exile servers.


## Installation
--------------------------
Copy the addons folder into your mpmission folder

add this to the bottom of your description.ext

#  #include "addons\defines.hpp"

next add this to your init.sqf
(if you dont have a init.sqf just create a new one)

[] execVM "addons\blowout_config.sqf";


## Credits
--------------------------
Author: Sumrak (2010)
Contributors: hawkie52, Major Khunt (2016), FallingSheep (2016)



