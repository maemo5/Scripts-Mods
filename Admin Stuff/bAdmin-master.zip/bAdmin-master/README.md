# bAdmin
Admin Panel from A3Wasteland ported and customized for exile

Tutorial to install: http://www.exilemod.com/topic/1146-badmin-in-game-admin-menu-from-a3w/
