# ExHP
Adds actions to a player so they can eject from air vehicles and pull a parachute without actually wearing one.

## Dependencies
 * Exile Mod

## Installation
* Add the content from description.ext into you own description.ext inside the mission root folder.  
* Add the ExHP folder into the mission root folder.

## Update
* Replace ExHP in the mission root folder

##Contribute
Contributions are allways welcome, please read [Contribution Guidlines](CONTRIBUTING.md) first.

All contributed code first needs to be rewieved before pushed to master. 

##Contact
For this project I only reply through my [Exile profile](http://www.exilemod.com/profile/7143-janski/)  
If you want help with an issue, report a bug or maybe just request a new feature first make sure now one else have had the same issue by searching the [Issue Tracker](https://github.com/Bjanski/Exile_halo_parachute/issues) and the [Exile Forum](http://www.exilemod.com/).
