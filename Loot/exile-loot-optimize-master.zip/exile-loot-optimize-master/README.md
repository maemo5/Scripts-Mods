# exile-loot-optimize
This is just optimize loot for Exile, how loot spawns / despawns is still the same logic


  
  http://www.exilemod.com/topic/9312-exile-loot-optimize-overrides-incomplete/
