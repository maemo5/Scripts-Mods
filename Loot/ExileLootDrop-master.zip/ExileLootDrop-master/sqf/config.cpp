class CfgPatches {
	class ExileLootDrop {
		requiredVersion = 0.1;
		requiredAddons[] = {"exile_server"};
		units[] = {};
		weapons[] = {};
		magazines[] = {};
		ammo[] = {};
	};
};
