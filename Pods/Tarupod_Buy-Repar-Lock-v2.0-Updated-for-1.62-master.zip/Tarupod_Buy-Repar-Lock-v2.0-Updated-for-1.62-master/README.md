# Tarupod_Buy-Repar-Lock-v2.0-Updated-for-1.62-
These collections of modifications and scripts that I have made will allow you to buy, repair, lock, and flip tarupods. Finally an all in one download solution.
The installation instructions are in the Readme.cpp file in the folder that i created.
