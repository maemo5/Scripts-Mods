	class JonzieCars
	{
		name = "Jonzie Cars";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
		///////////////////////////////////////////////////////////////////////////////
		// CARS
		///////////////////////////////////////////////////////////////////////////////
		"Jonzie_30CSL",					//BMW3.0 CSL
        "Jonzie_Escalade",              //Cadillac Escalade
        "Jonzie_Curtain_Roadtrain",		//Curtain B Trailer
        "Jonzie_Curtain",				//Curtain Trailer
        "Jonzie_Datsun_510",			//Datsun Bluebird
        "Jonzie_Datsun_Z432",			//Datsun Fairlady Z432
        "Jonzie_Viper",					//Dodge Viper
        "Jonzie_Flatbed_Roadtrain",		//Flatbed B-Trailer
        "Jonzie_Flatbed",				//Flatbed Trailer
        "Jonzie_Raptor",				//Ford F150 Raptor
        "Jonzie_XB",					//Ford Falcon XB
        "Jonzie_Transit",				//Ford Transit
        "Jonzie_Forklift",				//Forlift
        "Jonzie_VE",					//Holden Commodore
        "Jonzie_Highway",				//Holden Commodore Highway Patrol
        "Jonzie_Ute",					//Holden Commodore Ute
        "Jonzie_Ceed",					//Kia cee'd
        "Jonzie_Superliner",			//Mack Superliner 273
        "Jonzie_Box_Truck",			    //MAN TGX Box Truck
        "Jonzie_Flat_Bed",				//MAN TGX Flat Bed Truck
        "Jonzie_Log_Truck",				//MAN TGX Long Log Truck
        "Jonzie_Tanker_Truck",			//MAN TGX Tanker Truck
        "Jonzie_Tow_Truck",				//MAN TGX Tow Truck
        "Jonzie_Quattroporte",			//Maserati Quattroporte
        "Jonzie_Mini_Cooper_R_spec",	//Mini Cooper Rally Spec
        "Jonzie_Galant",				//Mitsubishi Galant
        "Jonzie_STI",					//Subaru WRX STI
        "Jonzie_Corolla",				//Toyota Sprinter
        "Jonzie_Western",				//Western Star 4900
        "Jonzie_Pallet_Empty"			//Pallet Empty

		};
	};
