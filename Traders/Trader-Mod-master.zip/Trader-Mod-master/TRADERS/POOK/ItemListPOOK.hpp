	/////////////////////////////////////////////////////////////////////////////
	// Pook
	///////////////////////////////////////////////////////////////////////////////
	class pook_H13_amphib				{ quality = 1; price = 25000; };
	class pook_H13_civ					{ quality = 1; price = 25000; };
	class pook_H13_civ_black			{ quality = 1; price = 25000; };
	class pook_H13_civ_redwhite			{ quality = 1; price = 25000; };
	class pook_H13_civ_slate			{ quality = 1; price = 25000; };
	class pook_H13_civ_white			{ quality = 1; price = 25000; };
	class pook_H13_civ_yellow			{ quality = 1; price = 25000; };
	class pook_H13_gunship				{ quality = 1; price = 50000; };
	class pook_H13_medevac				{ quality = 1; price = 25000; };
	class pook_H13_transport			{ quality = 1; price = 25000; };