	///////////////////////////////////////////////////////////////////////////////
	// RHS Weapons [CiC]red_ned http://cic-gaming.co.uk
	// Thanks to its Dutch and John MCSwagatron for update of items
	///////////////////////////////////////////////////////////////////////////////

	/////////////////////////////////////////////////////////////////////////////
	// HAFM Tanks
	///////////////////////////////////////////////////////////////////////////////
	class Leopard2A6HEL												{ quality = 3; price = 6000000; };
	class Leopard2A6HEL_2											{ quality = 3; price = 6000000; };
	class Leopard2A4												{ quality = 3; price = 6000000; };
	class Leopard2A4_2												{ quality = 3; price = 6000000; };
	class Leopard1A4												{ quality = 3; price = 5000000; };
	class Leopard1A4_2												{ quality = 3; price = 5000000; };
	//APC
	class Leonidas2													{ quality = 3; price = 300000; };
	class Leonidas2_2												{ quality = 3; price = 300000; };
	//Cars and vans
	class HAFM_GD240												{ quality = 3; price = 25000; };
	class HAFM_GD240_Patrol											{ quality = 3; price = 25000; };
	class HAFM_GD240_Patrol2										{ quality = 3; price = 25000; };
	class HAFM_GD240_Unarmed										{ quality = 3; price = 25000; };
	class HAFM_GD240_Unarmed2										{ quality = 3; price = 25000; };
	class Unimog1550_Covered										{ quality = 3; price = 25000; };
	class Unimog1550_Covered2										{ quality = 3; price = 25000; };
	class Unimog1550_SemiCovered									{ quality = 3; price = 25000; };
	class Unimog1550_SemiCovered2									{ quality = 3; price = 25000; };
	//hmmwv
	class HAFM_HMMWV												{ quality = 3; price = 50000; };
	class HAFM_HMMWV1												{ quality = 3; price = 50000; };
	class HAFM_HMMWV1_M2											{ quality = 3; price = 150000; };
	class HAFM_HMMWV1_MK19											{ quality = 3; price = 200000; };
	class HAFM_HMMWV1_TOW											{ quality = 3; price = 250000; };
	class HAFM_HMMWV_M2												{ quality = 3; price = 150000; };
	class HAFM_HMMWV_MK19											{ quality = 3; price = 200000; };
	class HAFM_HMMWV_TOW											{ quality = 3; price = 250000; };
	// Heli normal
	class CH_47F													{ quality = 3; price = 50000; };
	class CH_47F_BLU												{ quality = 3; price = 50000; };
	class DEGA_BAF_CH47F_M134										{ quality = 3; price = 50000; };
	class DEGA_BAF_CH47F_M134_M240									{ quality = 3; price = 50000; };
	class DEGA_BAF_CH47F_Unarmed									{ quality = 3; price = 50000; };
	class DEGA_US_CH47F_M134										{ quality = 3; price = 50000; };
	class DEGA_US_CH47F_M134_M240									{ quality = 3; price = 50000; };
	class DEGA_US_CH47F_Unarmed										{ quality = 3; price = 50000; };
	class DEGA_Wildcat_Unarmed_BAF									{ quality = 3; price = 50000; };
	class DEGA_Wildcat_Unarmed_Digital_AAF							{ quality = 3; price = 50000; };
	class DEGA_Wildcat_Unarmed_Green_AAF							{ quality = 3; price = 50000; };
	class DEGA_Wildcat_Unarmed_RDAF									{ quality = 3; price = 50000; };
	class EC635														{ quality = 3; price = 2000000; };
	class EC635_ADAC												{ quality = 3; price = 50000; };
	class EC635_BW													{ quality = 3; price = 2000000; };
	class EC635_CSAT												{ quality = 3; price = 2000000; };
	class EC635_SAR													{ quality = 3; price = 50000; };
	class EC635_Unarmed												{ quality = 3; price = 50000; };
	class EC635_Unarmed_BW											{ quality = 3; price = 50000; };
	class EC635_Unarmed_CSAT										{ quality = 3; price = 50000; };
	class HAFM_UH1H													{ quality = 3; price = 50000; };
	class HAFM_UH1H_GR												{ quality = 3; price = 50000; };
	class NH90Armed_GR												{ quality = 3; price = 1000000; };
	class NH90Armed_GR2												{ quality = 3; price = 1000000; };
	class NH90_GR													{ quality = 3; price = 50000; };
	class NH90_GR2													{ quality = 3; price = 50000; };
	//Attack heli
	class DEGA_Apache_AH1_Block_II_BAF								{ quality = 3; price = 4000000; };
	class DEGA_Apache_AH1_Block_I_BAF								{ quality = 3; price = 4000000; };
	class DEGA_Apache_AH64D_Block_II_USA							{ quality = 3; price = 4000000; };
	class DEGA_Apache_AH64D_Block_I_USA								{ quality = 3; price = 4000000; };
	class DEGA_Wildcat_Cannon_Armed_BAF								{ quality = 3; price = 2000000; };
	class DEGA_Wildcat_Cannon_Armed_Digital_AAF						{ quality = 3; price = 2000000; };
	class DEGA_Wildcat_Cannon_Armed_Green_AAF						{ quality = 3; price = 2000000; };
	class DEGA_Wildcat_Cannon_Armed_RDAF							{ quality = 3; price = 2000000; };
	class DEGA_Wildcat_Hellfire_Armed_BAF							{ quality = 3; price = 2500000; };
	class DEGA_Wildcat_Hellfire_Armed_Digital_AAF					{ quality = 3; price = 2500000; };
	class DEGA_Wildcat_Hellfire_Armed_Green_AAF						{ quality = 3; price = 2500000; };
	class DEGA_Wildcat_Hellfire_Armed_RDAF							{ quality = 3; price = 2500000; };
	class EC635_AT													{ quality = 3; price = 3000000; };
	class EC635_AT_BW												{ quality = 3; price = 3000000; };
	class EC635_AT_CSAT												{ quality = 3; price = 3000000; };
	class HAFM_AH64D												{ quality = 3; price = 4000000; };
	class HAFM_AH64D_GR												{ quality = 3; price = 4000000; };
	//Plane
	class C130H														{ quality = 3; price = 100000; };
	class C130H_BLU													{ quality = 3; price = 100000; };
	//Jets
	class A7														{ quality = 3; price = 6000000; };
	class A7BLU														{ quality = 3; price = 6000000; };
	class A7BLU_TIGER												{ quality = 3; price = 6000000; };
	class A7_TIGER													{ quality = 3; price = 6000000; };
	class F16C														{ quality = 3; price = 10000000; };
	class F16C_BLU													{ quality = 3; price = 10000000; };
	class F16_B52													{ quality = 3; price = 10000000; };
	class F16_B52_BLU												{ quality = 3; price = 10000000; };
	class F35B														{ quality = 3; price = 12000000; };
	class F35B_BLU													{ quality = 3; price = 12000000; };
	class F4E														{ quality = 3; price = 12500000; };
	class F4E_AG													{ quality = 3; price = 12500000; };
	class F4E_BLU													{ quality = 3; price = 12500000; };
	class F4E_BLU_AG												{ quality = 3; price = 12500000; };
	class M2000C													{ quality = 3; price = 8000000; };
	class M2000C_BLU												{ quality = 3; price = 8000000; };
	//Clothing
	class GR_A3_Uniform												{ quality = 3; price = 10000; };
	class GR_A4_Uniform												{ quality = 3; price = 10000; };
	class GR_A55_Uniform											{ quality = 3; price = 10000; };
	class GR_A5_Uniform												{ quality = 3; price = 10000; };
	class GR_AO_Frml_Uniform										{ quality = 3; price = 10000; };
	class GR_AO_Uniform												{ quality = 3; price = 10000; };
	class GR_A_Uniform												{ quality = 3; price = 10000; };
	class GR_Cap_NAVY												{ quality = 3; price = 5000; };
	class GR_E_Wetsuit												{ quality = 3; price = 10000; };
	class GR_F_NRF													{ quality = 3; price = 10000; };
	class GR_G_Uniform												{ quality = 3; price = 10000; };
	class GR_HeliPilot_Uniform										{ quality = 3; price = 10000; };
	class GR_NAVY_Uniform											{ quality = 3; price = 10000; };
	class GR_PlateCarrier											{ quality = 3; price = 15000; };
	class GR_PlateCarrier_B											{ quality = 3; price = 15000; };
	class GR_PlateCarrier_P											{ quality = 3; price = 15000; };
	class GR_QRF_Beanie												{ quality = 3; price = 5000; };
	class GR_RebreatherB											{ quality = 3; price = 25000; };
	class GR_SWAT_Uniform											{ quality = 3; price = 10000; };
	class GR_TacVest_Police											{ quality = 3; price = 15000; };
	class Greek_A_Helmet											{ quality = 3; price = 5000; };
	class Greek_A_Helmet_Black										{ quality = 3; price = 5000; };
	class Greek_A_Pilot_Helmet										{ quality = 3; price = 5000; };
	class Greek_A_Rig_Oil											{ quality = 3; price = 15000; };
	class Greek_A_cap												{ quality = 3; price = 5000; };
	class Greek_AssaultPack											{ quality = 3; price = 25000; };
	class Greek_AssaultPack_Black									{ quality = 3; price = 25000; };
	class Greek_AssaultPack_LAT										{ quality = 3; price = 25000; };
	class Greek_Berret												{ quality = 3; price = 5000; };
	class Greek_Berret1												{ quality = 3; price = 5000; };
	class Greek_EngineerPack										{ quality = 3; price = 25000; };
	class Greek_MedicPack											{ quality = 3; price = 25000; };
	class Greek_MedicPack_B											{ quality = 3; price = 25000; };
	class Greek_Modern_Helmet										{ quality = 3; price = 5000; };
	class Greek_P_cap												{ quality = 3; price = 5000; };
	class HAFM_MYK_Helmet											{ quality = 3; price = 5000; };
	class HAFM_Officer_Hat											{ quality = 3; price = 5000; };
	class H_Booniehat_GR											{ quality = 3; price = 5000; };
	class Sabot_Bergen												{ quality = 3; price = 25000; };
	class Sabot_Bergen_Black										{ quality = 3; price = 25000; };