	///////////////////////////////////////////////////////////////////////////////
	// MAS Weapons
	///////////////////////////////////////////////////////////////////////////////

	///////////////////////////////////////////////////////////////////////////////
	// Shemags
	///////////////////////////////////////////////////////////////////////////////
	class G_mas_wpn_gog								{ quality = 1; price = 50; };
	class G_mas_wpn_gog_d							{ quality = 1; price = 50; };
	class G_mas_wpn_gog_m							{ quality = 1; price = 50; };
	class G_mas_wpn_gog_md							{ quality = 1; price = 50; };
	class G_mas_wpn_gog_g							{ quality = 1; price = 50; };
	class G_mas_wpn_gog_gd							{ quality = 1; price = 50; };
	class G_mas_wpn_mask							{ quality = 1; price = 50; };
	class G_mas_wpn_mask_b							{ quality = 1; price = 50; };
	class G_mas_wpn_wrap							{ quality = 1; price = 50; };
	class G_mas_wpn_wrap_f							{ quality = 1; price = 50; };
	class G_mas_wpn_wrap_t							{ quality = 1; price = 50; };
	class G_mas_wpn_wrap_b							{ quality = 1; price = 50; };
	class G_mas_wpn_wrap_c							{ quality = 1; price = 50; };
	class G_mas_wpn_wrap_g							{ quality = 1; price = 50; };
	class G_mas_wpn_wrap_gog						{ quality = 1; price = 50; };
	class G_mas_wpn_wrap_gog_f						{ quality = 1; price = 50; };
	class G_mas_wpn_wrap_gog_t						{ quality = 1; price = 50; };
	class G_mas_wpn_wrap_gog_b						{ quality = 1; price = 50; };
	class G_mas_wpn_wrap_gog_c						{ quality = 1; price = 50; };
	class G_mas_wpn_wrap_gog_g						{ quality = 1; price = 50; };
	class G_mas_wpn_wrap_mask						{ quality = 1; price = 50; };
	class G_mas_wpn_wrap_mask_t						{ quality = 1; price = 50; };
	class G_mas_wpn_wrap_mask_f						{ quality = 1; price = 50; };
	class G_mas_wpn_wrap_mask_b						{ quality = 1; price = 50; };
	class G_mas_wpn_wrap_mask_c						{ quality = 1; price = 50; };
	class G_mas_wpn_wrap_mask_g						{ quality = 1; price = 50; };
	class G_mas_wpn_bala							{ quality = 1; price = 50; };
	class G_mas_wpn_bala_b							{ quality = 1; price = 50; };
	class G_mas_wpn_bala_t							{ quality = 1; price = 50; };
	class G_mas_wpn_bala_gog						{ quality = 1; price = 50; };
	class G_mas_wpn_bala_gog_b						{ quality = 1; price = 50; };
	class G_mas_wpn_bala_gog_t						{ quality = 1; price = 50; };
	class G_mas_wpn_bala_mask						{ quality = 1; price = 50; };
	class G_mas_wpn_bala_mask_b						{ quality = 1; price = 50; };
	class G_mas_wpn_bala_mask_t						{ quality = 1; price = 50; };
	class G_mas_wpn_shemag							{ quality = 1; price = 50; };
	class G_mas_wpn_shemag_r						{ quality = 1; price = 50; };
	class G_mas_wpn_shemag_w						{ quality = 1; price = 50; };
	class G_mas_wpn_shemag_gog						{ quality = 1; price = 50; };
	class G_mas_wpn_shemag_mask						{ quality = 1; price = 50; };
	class G_mas_wpn_gasmask							{ quality = 1; price = 50; };

	///////////////////////////////////////////////////////////////////////////////
	// Pointer Attachments
	///////////////////////////////////////////////////////////////////////////////
	class acc_mas_flash_gun 						{ quality = 1; price = 100; };
	class acc_mas_pointer_gun_IR 					{ quality = 1; price = 100; };
	class acc_mas_pointer_IR 						{ quality = 1; price = 100; };
	class acc_mas_pointer_IR_b 						{ quality = 1; price = 100; };
	class acc_mas_pointer_IR_top 					{ quality = 1; price = 100; };
	class acc_mas_pointer_IR_top_b 					{ quality = 1; price = 100; };
	class acc_mas_pointer_IR2 						{ quality = 1; price = 100; };
	class acc_mas_pointer_IR2_top 					{ quality = 1; price = 100; };
	class acc_mas_pointer_IR2c 						{ quality = 1; price = 100; };
	class acc_mas_pointer_IR2c_top					{ quality = 1; price = 100; };

	///////////////////////////////////////////////////////////////////////////////
	// Muzzle Attachments
	///////////////////////////////////////////////////////////////////////////////
	class muzzle_mas_snds_L 						{ quality = 1; price = 120; };
	class muzzle_mas_snds_LM 						{ quality = 1; price = 120; };
	class muzzle_mas_snds_C 						{ quality = 2; price = 120; };
	class muzzle_mas_snds_MP5SD6 					{ quality = 2; price = 120; };
	class muzzle_mas_snds_M 						{ quality = 2; price = 120; };
	class muzzle_mas_snds_Mc 						{ quality = 2; price = 120; };
	class muzzle_mas_snds_MP7 						{ quality = 2; price = 120; };
	class muzzle_mas_snds_AK 						{ quality = 2; price = 120; };
	class muzzle_mas_snds_SM 						{ quality = 2; price = 120; };
	class muzzle_mas_snds_SMc 						{ quality = 2; price = 120; };
	class muzzle_mas_snds_SH 						{ quality = 2; price = 120; };
	class muzzle_mas_snds_SHc 						{ quality = 2; price = 120; };
	class muzzle_mas_snds_SV 						{ quality = 2; price = 120; };
	class muzzle_mas_snds_SVc 						{ quality = 2; price = 120; };
	class muzzle_mas_snds_SVD 						{ quality = 2; price = 120; };
	class muzzle_mas_snds_KSVK 						{ quality = 2; price = 200; };

	///////////////////////////////////////////////////////////////////////////////
	// Optic Attachments
	///////////////////////////////////////////////////////////////////////////////
	class optic_mas_DMS								{ quality = 1; price = 150; };
	class optic_mas_DMS_c							{ quality = 1; price = 150; };
	class optic_mas_Holosight_blk					{ quality = 1; price = 150; };
	class optic_mas_Holosight_camo					{ quality = 1; price = 150; };
	class optic_mas_Arco_blk						{ quality = 1; price = 150; };
	class optic_mas_Arco_camo						{ quality = 1; price = 150; };
	class optic_mas_Hamr_camo						{ quality = 1; price = 150; };
	class optic_mas_Aco_camo						{ quality = 1; price = 150; };
	class optic_mas_ACO_grn_camo					{ quality = 1; price = 150; };
	class optic_mas_MRCO_camo						{ quality = 1; price = 100; };
	class optic_mas_zeiss							{ quality = 3; price = 300; };
	class optic_mas_zeiss_c							{ quality = 3; price = 300; };
	class optic_mas_zeiss_eo						{ quality = 3; price = 400; };
	class optic_mas_zeiss_eo_c						{ quality = 3; price = 400; };
	class optic_mas_acog							{ quality = 3; price = 200; };
	class optic_mas_acog_c							{ quality = 3; price = 200; };
	class optic_mas_acog_eo							{ quality = 3; price = 200; };
	class optic_mas_acog_eo_c						{ quality = 3; price = 200; };
	class optic_mas_acog_rd							{ quality = 3; price = 200; };
	class optic_mas_acog_rd_c						{ quality = 3; price = 200; };
	class optic_mas_handle							{ quality = 2; price = 100; };
	class optic_mas_aim								{ quality = 2; price = 150; };
	class optic_mas_aim_c							{ quality = 2; price = 150; };
	class optic_mas_PSO								{ quality = 3; price = 300; };
	class optic_mas_PSO_c							{ quality = 3; price = 300; };
	class optic_mas_PSO_eo							{ quality = 3; price = 300; };
	class optic_mas_PSO_eo_c						{ quality = 3; price = 300; };
	class optic_mas_PSO_nv							{ quality = 2; price = 500; };
	class optic_mas_PSO_nv_c						{ quality = 2; price = 500; };
	class optic_mas_PSO_nv_eo						{ quality = 2; price = 500; };
	class optic_mas_PSO_nv_eo_c						{ quality = 2; price = 500; };
	class optic_mas_PSO_day							{ quality = 3; price = 300; };
	class optic_mas_PSO_nv_day						{ quality = 2; price = 500; };
	class optic_mas_term							{ quality = 3; price = 600; };
	class optic_mas_MRD								{ quality = 1; price = 100; };
	class optic_mas_LRPS							{ quality = 3; price = 300; };
	class optic_mas_kobra							{ quality = 2; price = 250; };
	class optic_mas_kobra_c							{ quality = 2; price = 250; };
	class optic_mas_nspu							{ quality = 2; price = 250; };
	class optic_mas_goshawk							{ quality = 2; price = 150; };
	class optic_mas_PSO_kv							{ quality = 2; price = 250; };
	class optic_mas_PSO_kv_c						{ quality = 2; price = 250; };

	///////////////////////////////////////////////////////////////////////////////
	// Navigation
	///////////////////////////////////////////////////////////////////////////////
	class NVGoggles_mas_h							{ quality = 2; price = 250; };
	class Rangefinder_mas_h							{ quality = 2; price = 250; };
	class Laserdesignator_mas_h						{ quality = 3; price = 950; };

	///////////////////////////////////////////////////////////////////////////////
	// Backpacks
	///////////////////////////////////////////////////////////////////////////////
	class B_mas_m_Bergen_us							{ quality = 2; price = 200; };
	class B_mas_m_Bergen_us_g						{ quality = 2; price = 200; };
	class B_mas_m_Bergen_us_m						{ quality = 2; price = 200; };
	class B_mas_m_Bergen_us_b						{ quality = 2; price = 200; };
	class B_mas_m_Bergen_us_w						{ quality = 2; price = 200; };
	class B_mas_m_Bergen_acr						{ quality = 2; price = 200; };
	class B_mas_m_Bergen_acr_c						{ quality = 2; price = 200; };
	class B_mas_m_Bergen_acr_g						{ quality = 2; price = 200; };
	class B_mas_m_Bergen_acr_w						{ quality = 2; price = 200; };
	class B_mas_m_Bergen_rpg						{ quality = 2; price = 200; };
	class B_mas_m_Bergen_rpg_b						{ quality = 2; price = 200; };
	class B_mas_m_Bergen_al							{ quality = 2; price = 200; };
	class B_mas_AssaultPack_mul						{ quality = 1; price = 150; };
	class B_mas_Kitbag_mul							{ quality = 3; price = 200; };
	class B_mas_Bergen_mul							{ quality = 2; price = 200; };
	class B_mas_AssaultPack_des						{ quality = 1; price = 150; };
	class B_mas_Kitbag_des							{ quality = 3; price = 200; };
	class B_mas_Bergen_des							{ quality = 2; price = 200; };
	class B_mas_AssaultPack_black					{ quality = 1; price = 150; };
	class B_mas_Kitbag_black						{ quality = 3; price = 200; };
	class B_mas_Bergen_black						{ quality = 2; price = 200; };
	class B_mas_AssaultPack_wint					{ quality = 1; price = 150; };
	class B_mas_Kitbag_wint							{ quality = 3; price = 200; };
	class B_mas_Bergen_wint							{ quality = 2; price = 200; };
	class B_mas_AssaultPack_rng						{ quality = 1; price = 150; };
	class B_mas_Kitbag_rng							{ quality = 3; price = 200; };
	class B_mas_Bergen_rng							{ quality = 2; price = 200; };
	class O_mas_Bergen_flo							{ quality = 2; price = 200; };
	class O_mas_Bergen_blk							{ quality = 2; price = 200; };
	class O_mas_Bergen_rtan							{ quality = 2; price = 200; };

	///////////////////////////////////////////////////////////////////////////////
	// Ammunition
	///////////////////////////////////////////////////////////////////////////////
	class 30Rnd_mas_556x45_Stanag					{ quality = 1; price = 20; };
	class 30Rnd_mas_556x45_T_Stanag					{ quality = 2; price = 20; };
	class 30Rnd_mas_556x45sd_Stanag					{ quality = 2; price = 20; };
	class 200Rnd_mas_556x45_Stanag					{ quality = 1; price = 30; };
	class 200Rnd_mas_556x45_T_Stanag				{ quality = 2; price = 30; };
	class 100Rnd_mas_762x51_Stanag					{ quality = 1; price = 30; };
	class 100Rnd_mas_762x51_T_Stanag				{ quality = 2; price = 40; };
	class 100Rnd_mas_762x54_mag						{ quality = 1; price = 30; };
	class 100Rnd_mas_762x54_T_mag					{ quality = 2; price = 40; };
	class 100Rnd_mas_762x39_mag						{ quality = 1; price = 30; };
	class 100Rnd_mas_762x39_T_mag					{ quality = 2; price = 40; };
	class 30Rnd_mas_545x39_mag						{ quality = 1; price = 20; };
	class 30Rnd_mas_545x39_T_mag					{ quality = 2; price = 20; };
	class 100Rnd_mas_545x39_mag						{ quality = 1; price = 25; };
	class 100Rnd_mas_545x39_T_mag					{ quality = 2; price = 25; };
	class 20Rnd_mas_762x51_Stanag					{ quality = 1; price = 20; };
	class 20Rnd_mas_762x51_T_Stanag					{ quality = 2; price = 20; };
	class 20Rnd_mas_762x51sd_Stanag 				{ quality = 2; price = 20; };
	class 5Rnd_mas_762x51_Stanag					{ quality = 1; price = 20; };
	class 5Rnd_mas_762x51_T_Stanag					{ quality = 2; price = 20; };
	class 10Rnd_mas_338_Stanag						{ quality = 1; price = 30; };
	class 10Rnd_mas_338_T_Stanag					{ quality = 2; price = 30; };
	class 30Rnd_mas_762x39_mag						{ quality = 1; price = 20; };
	class 30Rnd_mas_762x39_T_mag					{ quality = 2; price = 20; };
	class 10Rnd_mas_762x54_mag						{ quality = 1; price = 25; };
	class 10Rnd_mas_762x54_T_mag					{ quality = 2; price = 25; };
	class 5Rnd_mas_127x99_Stanag					{ quality = 1; price = 50; };
	class 5Rnd_mas_127x99_T_Stanag					{ quality = 2; price = 50; };
	class 5Rnd_mas_127x108_mag						{ quality = 1; price = 40; };
	class 5Rnd_mas_127x108_T_mag					{ quality = 2; price = 40; };
	class 30Rnd_mas_9x21_Stanag						{ quality = 1; price = 10; };
	class 30Rnd_mas_9x21d_Stanag					{ quality = 1; price = 10; };
	class 12Rnd_mas_45acp_Mag						{ quality = 1; price = 15; };
	class 10Rnd_mas_45acp_Mag						{ quality = 1; price = 15; };
	class 8Rnd_mas_45acp_Mag						{ quality = 1; price = 15; };
	class 15Rnd_mas_9x21_Mag						{ quality = 1; price = 15; };
	class 17Rnd_mas_9x21_Mag						{ quality = 1; price = 15; };
	class 13Rnd_mas_9x21_Mag						{ quality = 1; price = 15; };
	class 8Rnd_mas_9x18_mag							{ quality = 1; price = 15; };
	class 7Rnd_mas_12Gauge_Slug						{ quality = 1; price = 10; };
	class 7Rnd_mas_12Gauge_Pellets					{ quality = 1; price = 10; };
	class 10Rnd_mas_12Gauge_Slug					{ quality = 1; price = 10; };
	class 10Rnd_mas_12Gauge_Pellets					{ quality = 1; price = 10; };
	class 64Rnd_mas_9x18_mag						{ quality = 1; price = 20; };
	class 20Rnd_mas_765x17_Mag						{ quality = 1; price = 20; };
	class 25Rnd_mas_9x19_Mag						{ quality = 1; price = 20; };
	class 40Rnd_mas_46x30_Mag						{ quality = 1; price = 30; };
	class 20Rnd_mas_12Gauge_Slug					{ quality = 1; price = 20; };
	class 20Rnd_mas_12Gauge_Pellets					{ quality = 1; price = 20; };
	class 150Rnd_mas_556x45_Stanag					{ quality = 1; price = 30; };
	class 150Rnd_mas_556x45_T_Stanag				{ quality = 2; price = 30; };
	class 30Rnd_mas_9x39_mag						{ quality = 2; price = 40; };
	class 20Rnd_mas_9x39_mag						{ quality = 2; price = 30; };
	class 5Rnd_mas_127x99_dem_Stanag				{ quality = 2; price = 90; };
	class 5Rnd_mas_127x108_dem_mag  				{ quality = 2; price = 90; };

	///////////////////////////////////////////////////////////////////////////////
	// Pistols
	///////////////////////////////////////////////////////////////////////////////
	class hgun_mas_mp7p_F 							{ quality = 2; price = 300; };
	class hgun_mas_uzi_F 							{ quality = 2; price = 300; };
	class hgun_mas_sa61_F 							{ quality = 2; price = 300; };
	class hgun_mas_m9_F 							{ quality = 1; price = 250; };
	class hgun_mas_bhp_F 							{ quality = 1; price = 250; };
	class hgun_mas_glock_F 							{ quality = 2; price = 250; };
	class hgun_mas_p226_F 							{ quality = 2; price = 250; };
	class hgun_mas_acp_F 							{ quality = 2; price = 250; };
	class hgun_mas_usp_F 							{ quality = 2; price = 250; };
	class hgun_mas_usp_l_F 							{ quality = 2; price = 250; };
	class hgun_mas_glocksf_F 						{ quality = 2; price = 250; };
	class hgun_mas_grach_F 							{ quality = 1; price = 250; };
	class hgun_mas_mak_F 							{ quality = 1; price = 250; };
	class hgun_mas_mak_F_sd 						{ quality = 1; price = 250; };

	///////////////////////////////////////////////////////////////////////////////
	// Sub Machine Guns
	///////////////////////////////////////////////////////////////////////////////
	class arifle_mas_mp40 							{ quality = 1; price = 250; };
	class arifle_mas_mp40_o 						{ quality = 1; price = 250; };
	class arifle_mas_sten 							{ quality = 1; price = 250; };
	class arifle_mas_m1014 							{ quality = 2; price = 300; };
	class arifle_mas_aa12 							{ quality = 2; price = 400; };
	class arifle_mas_m79 							{ quality = 2; price = 400; };
	class arifle_mas_mp5 							{ quality = 2; price = 400; };
	class arifle_mas_mp5_v 							{ quality = 2; price = 400; };
	class arifle_mas_mp5_d 							{ quality = 2; price = 500; };
	class arifle_mas_mp5sd_ds 						{ quality = 2; price = 600; };
	class hgun_mas_mp7_F 							{ quality = 2; price = 300; };
	class arifle_mas_bizon 							{ quality = 1; price = 450; };
	class arifle_mas_saiga 							{ quality = 2; price = 300; };

	///////////////////////////////////////////////////////////////////////////////
	// Light Machine Guns
	///////////////////////////////////////////////////////////////////////////////
	class arifle_mas_m27							{ quality = 2; price = 550; };
	class arifle_mas_m27m							{ quality = 2; price = 550; };
	class arifle_mas_m27_v							{ quality = 2; price = 550; };
	class arifle_mas_m27m_v							{ quality = 2; price = 550; };
	class arifle_mas_m27_d							{ quality = 2; price = 550; };
	class arifle_mas_m27m_d							{ quality = 2; price = 550; };
	class LMG_mas_Mk200_F							{ quality = 3; price = 400; };
	class LMG_mas_M249_F							{ quality = 3; price = 500; };
	class LMG_mas_M249_F_v							{ quality = 3; price = 500; };
	class LMG_mas_M249_F_d							{ quality = 3; price = 500; };
	class LMG_mas_M249a_F							{ quality = 3; price = 500; };
	class LMG_mas_Mk48_F							{ quality = 3; price = 450; };
	class LMG_mas_Mk48_F_v							{ quality = 3; price = 450; };
	class LMG_mas_Mk48_F_d							{ quality = 3; price = 450; };
	class LMG_mas_M240_F							{ quality = 3; price = 600; };
	class LMG_mas_mg3_F								{ quality = 3; price = 800; };
	class LMG_mas_M60_F								{ quality = 3; price = 600; };
	class LMG_mas_m72_F								{ quality = 2; price = 550; };
	class LMG_mas_rpk_F								{ quality = 2; price = 550; };
	class LMG_mas_pkm_F								{ quality = 3; price = 650; };
	class LMG_mas_pech_F							{ quality = 3; price = 700; };

	///////////////////////////////////////////////////////////////////////////////
	// Assault Rifles
	///////////////////////////////////////////////////////////////////////////////
	class arifle_mas_hk416							{ quality = 1; price = 350; };
	class arifle_mas_hk416_gl						{ quality = 2; price = 450; };
	class arifle_mas_hk416_m203						{ quality = 2; price = 450; };
	class arifle_mas_hk416_v						{ quality = 1; price = 350; };
	class arifle_mas_hk416_gl_v						{ quality = 2; price = 450; };
	class arifle_mas_hk416_m203_v					{ quality = 2; price = 450; };
	class arifle_mas_hk416_d						{ quality = 1; price = 350; };
	class arifle_mas_hk416_gl_d						{ quality = 2; price = 450; };
	class arifle_mas_hk416_m203_d					{ quality = 2; price = 450; };
	class arifle_mas_hk416c							{ quality = 1; price = 300; };
	class arifle_mas_hk416_m203c					{ quality = 2; price = 400; };
	class arifle_mas_hk416c_v						{ quality = 1; price = 300; };
	class arifle_mas_hk416_m203c_v					{ quality = 2; price = 400; };
	class arifle_mas_hk416c_d						{ quality = 1; price = 300; };
	class arifle_mas_hk416_m203c_d					{ quality = 2; price = 400; };
	class arifle_mas_m4								{ quality = 1; price = 350; };
	class arifle_mas_m4_gl							{ quality = 2; price = 450; };
	class arifle_mas_m4_m203						{ quality = 2; price = 450; };
	class arifle_mas_m4_v							{ quality = 1; price = 350; };
	class arifle_mas_m4_gl_v						{ quality = 2; price = 450; };
	class arifle_mas_m4_m203_v						{ quality = 2; price = 450; };
	class arifle_mas_m4_d							{ quality = 1; price = 350; };
	class arifle_mas_m4_gl_d						{ quality = 2; price = 450; };
	class arifle_mas_m4_m203_d						{ quality = 2; price = 450; };
	class arifle_mas_m4vlt							{ quality = 1; price = 400; };
	class arifle_mas_m4c							{ quality = 1; price = 300; };
	class arifle_mas_m4_m203c						{ quality = 2; price = 400; };
	class arifle_mas_m4c_v							{ quality = 1; price = 300; };
	class arifle_mas_m4_m203c_v						{ quality = 2; price = 400; };
	class arifle_mas_m4c_d							{ quality = 1; price = 300; };
	class arifle_mas_m4_m203c_d						{ quality = 2; price = 400; };
	class arifle_mas_m16							{ quality = 2; price = 500; };
	class arifle_mas_m16_gl							{ quality = 2; price = 600; };
	class arifle_mas_l119							{ quality = 1; price = 350; };
	class arifle_mas_l119c							{ quality = 1; price = 300; };
	class arifle_mas_l119_gl						{ quality = 2; price = 450; };
	class arifle_mas_l119_m203						{ quality = 2; price = 450; };
	class arifle_mas_l119_v							{ quality = 1; price = 350; };
	class arifle_mas_l119c_v						{ quality = 1; price = 300; };
	class arifle_mas_l119_gl_v						{ quality = 2; price = 450; };
	class arifle_mas_l119_m203_v					{ quality = 2; price = 450; };
	class arifle_mas_l119_d							{ quality = 1; price = 350; };
	class arifle_mas_l119c_d						{ quality = 1; price = 300; };
	class arifle_mas_l119_gl_d						{ quality = 2; price = 450; };
	class arifle_mas_l119_m203_d					{ quality = 2; price = 450; };
	class arifle_mas_g36c							{ quality = 1; price = 400; };
	class arifle_mas_mk16							{ quality = 1; price = 350; };
	class arifle_mas_mk16_gl						{ quality = 2; price = 450; };
	class arifle_mas_mk16_l							{ quality = 1; price = 400; };
	class arifle_mas_mk16_l_gl						{ quality = 2; price = 450; };
	class arifle_mas_mk17							{ quality = 1; price = 450; };
	class arifle_mas_mk17_gl						{ quality = 2; price = 550; };
	class arifle_mas_arx							{ quality = 1; price = 350; };
	class arifle_mas_arx_gl							{ quality = 2; price = 450; };
	class arifle_mas_arx_l							{ quality = 1; price = 400; };
	class arifle_mas_arx_l_gl						{ quality = 2; price = 450; };
	class arifle_mas_g3								{ quality = 1; price = 500; };
	class arifle_mas_g3_m203						{ quality = 2; price = 600; };
	class arifle_mas_g3s							{ quality = 1; price = 500; };
	class arifle_mas_g3s_m203						{ quality = 2; price = 600; };
	class arifle_mas_fal							{ quality = 1; price = 500; };
	class arifle_mas_fal_m203						{ quality = 2; price = 600; };
	class arifle_mas_ak_74m							{ quality = 1; price = 450; };
	class arifle_mas_ak_74m_gl						{ quality = 2; price = 550; };
	class arifle_mas_ak_74m_c						{ quality = 2; price = 400; };
	class arifle_mas_ak_74m_gl_c					{ quality = 2; price = 500; };
	class arifle_mas_aks74							{ quality = 1; price = 450; };
	class arifle_mas_aks74_gl						{ quality = 2; price = 550; };
	class arifle_mas_ak74							{ quality = 2; price = 400; };
	class arifle_mas_ak74_gl						{ quality = 2; price = 500; };
	class arifle_mas_ak_74m_sf						{ quality = 1; price = 450; };
	class arifle_mas_ak_74m_sf_gl					{ quality = 2; price = 550; };
	class arifle_mas_ak_74m_sf_c					{ quality = 1; price = 400; };
	class arifle_mas_ak_74m_sf_gl_c					{ quality = 2; price = 500; };
	class arifle_mas_aks_74_sf						{ quality = 1; price = 450; };
	class arifle_mas_aks_74_sf_gl					{ quality = 2; price = 550; };
	class arifle_mas_ak12_sf						{ quality = 1; price = 350; };
	class arifle_mas_ak12_sf_gl						{ quality = 2; price = 450; };
	class arifle_mas_akms							{ quality = 2; price = 300; };
	class arifle_mas_akms_gl						{ quality = 2; price = 400; };
	class arifle_mas_akms_c							{ quality = 2; price = 300; };
	class arifle_mas_akms_gl_c						{ quality = 2; price = 400; };
	class arifle_mas_akm							{ quality = 2; price = 300; };
	class arifle_mas_akm_gl							{ quality = 2; price = 400; };
	class arifle_mas_m70							{ quality = 1; price = 450; };
	class arifle_mas_m70_gl							{ quality = 2; price = 550; };
	class arifle_mas_m70ab							{ quality = 1; price = 450; };
	class arifle_mas_m70ab_gl						{ quality = 2; price = 550; };
	class arifle_mas_asval							{ quality = 2; price = 650; };
	class arifle_mas_asval_ds						{ quality = 2; price = 650; };
	class arifle_mas_aks74u							{ quality = 2; price = 300; };
	class arifle_mas_aks74u_c						{ quality = 2; price = 350; };

	///////////////////////////////////////////////////////////////////////////////
	// Sniper Rifles
	///////////////////////////////////////////////////////////////////////////////
	class arifle_mas_hk417c 						{ quality = 2; price = 650; };
	class arifle_mas_hk417_m203c					{ quality = 3; price = 750; };
	class arifle_mas_hk417c_v						{ quality = 2; price = 650; };
	class arifle_mas_hk417_m203c_v					{ quality = 3; price = 750; };
	class arifle_mas_hk417c_d						{ quality = 2; price = 650; };
	class arifle_mas_hk417_m203c_d					{ quality = 3; price = 750; };
	class arifle_mas_m14							{ quality = 3; price = 750; };
	class arifle_mas_lee							{ quality = 3; price = 750; };
	class srifle_mas_hk417							{ quality = 2; price = 700; };
	class srifle_mas_hk417_v						{ quality = 2; price = 700; };
	class srifle_mas_hk417_d						{ quality = 2; price = 700; };
	class srifle_mas_sr25							{ quality = 2; price = 700; };
	class srifle_mas_sr25_v							{ quality = 2; price = 700; };
	class srifle_mas_sr25_d							{ quality = 2; price = 700; };
	class srifle_mas_ebr							{ quality = 2; price = 700; };
	class srifle_mas_mk17s							{ quality = 2; price = 700; };
	class srifle_mas_m110							{ quality = 2; price = 800; };
	class srifle_mas_m107 							{ quality = 3; price = 1000; };
	class srifle_mas_m107_v 						{ quality = 3; price = 1000; };
	class srifle_mas_m107_d 						{ quality = 3; price = 1000; };
	class srifle_mas_m24							{ quality = 2; price = 750; };
	class srifle_mas_m24_v							{ quality = 2; price = 750; };
	class srifle_mas_m24_d							{ quality = 2; price = 750; };
	class srifle_mas_lrr							{ quality = 2; price = 800; };
	class srifle_mas_m91							{ quality = 2; price = 700; };
	class srifle_mas_svd							{ quality = 2; price = 800; };
	class srifle_mas_vss							{ quality = 2; price = 750; };
	class srifle_mas_ksvk 							{ quality = 3; price = 1000; };
	class srifle_mas_ksvk_c 						{ quality = 3; price = 1000; };

	///////////////////////////////////////////////////////////////////////////////
	// Launchers
	///////////////////////////////////////////////////////////////////////////////
	class mas_launch_maaws_F 						{ quality = 1; price = 7500; };
	class mas_launch_smaw_F 						{ quality = 1; price = 7500; };
	class mas_launch_NLAW_F 						{ quality = 1; price = 7500; };
	class mas_launch_LAW_F 							{ quality = 1; price = 7500; };
	class mas_launch_M136_F 						{ quality = 1; price = 7500; };
	class mas_launch_TitanS_F 						{ quality = 1; price = 7500; };
	class mas_launch_RPG7_F 						{ quality = 1; price = 7500; };
	class mas_launch_RPG18_F 						{ quality = 1; price = 7500; };
	class mas_launch_Metis_F 						{ quality = 1; price = 7500; };
	class mas_launch_pzf60_F 						{ quality = 1; price = 7500; };
	class mas_launch_Stinger_F 						{ quality = 1; price = 7500; };
	class mas_launch_Strela_F 						{ quality = 1; price = 7500; };

	///////////////////////////////////////////////////////////////////////////////
	// Launcher Ammo
	///////////////////////////////////////////////////////////////////////////////
	class mas_MAAWS									{ quality = 1; price = 3000; };
	class mas_MAAWS_HE								{ quality = 1; price = 3000; };
	class mas_SMAW									{ quality = 1; price = 3000; };
	class mas_SMAW_HE								{ quality = 1; price = 3000; };
	class mas_SMAW_NE								{ quality = 1; price = 3000; };
	class mas_NLAW									{ quality = 1; price = 3000; };
	class mas_NLAW_HE								{ quality = 1; price = 3000; };
	class mas_LAW									{ quality = 1; price = 3000; };
	class mas_M136									{ quality = 1; price = 3000; };
	class mas_M136_HE								{ quality = 1; price = 3000; };
	class mas_TitanS								{ quality = 1; price = 3000; };
	class mas_TitanS_HE								{ quality = 1; price = 3000; };
	class mas_PG7V									{ quality = 1; price = 3000; };
	class mas_OG7									{ quality = 1; price = 3000; };
	class mas_PG7L									{ quality = 1; price = 3000; };
	class mas_PG7VR									{ quality = 1; price = 3000; };
	class mas_TBG7V									{ quality = 1; price = 3000; };
	class mas_PG18									{ quality = 1; price = 3000; };
	class mas_Metis									{ quality = 1; price = 3000; };
	class mas_Metis_HE								{ quality = 1; price = 3000; };
	class mas_pzf60									{ quality = 1; price = 3000; };
	class mas_Stinger								{ quality = 1; price = 3000; };
	class mas_Strela								{ quality = 1; price = 3000; };
