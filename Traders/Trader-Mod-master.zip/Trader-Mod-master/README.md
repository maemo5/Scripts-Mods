# Trader-Mod v7.2
<b>Exile Easy Trader Mod System</b><br>

This trader system is offered free without any guarantee or promise and users should back up their files before proceeding.<br>
It is compiled by [CiC]red_ned of http://cic-gaming.co.uk from different sources including documentation on exilemod and in game from various places.<br>
I have only compiled what i found, attempted to simplify class names and created files for what i couldn't find and is given back to the community as thanks.<br>
If you use then you should consider sharing any further development, bug fixes or expansions (as i have probably missed objects out or spelled things incorrectly).<br>
This file does not include how to install mods or add to loot tables as that is already well documented.<br><br>

<b>This is a major update so please report bugs on exilemod.com</b><br><br>

<b>v7.2 Update</b><br>
Added : TankDLC<br>
Thanks to @ItsDutch plus his contributors<br>

<b>v7.1 Update</b><br>
Added : HAFM<br>
Added : MASWW2<br>
Added : NLD<br>
Added : POOK<br>
Thanks to @ItsDutch plus his contributors<br>

<b>v7.0 Update</b><br>
Updated for Exile 1.0.4 "Pineapple"<br>

<b>v6.6 Update</b><br>
Added KA Mod - thanks to CHAINSAW SQUIRREL<br>
Text sorted some more files and checked optimisation of tabs not spaces<br>

<b>v6.5 Update</b><br>
Added new class ApexVTOL<br>
Added 100+ to ARMA3V<br>
Added 100+ to RHSV<br>
Fixed APEX<br>
Cleaned up some code<br>

<br><br>
<b>v6.3 Update</b><br>
Added 100+ vehicles into RHSV<br>
Added some missing Arma3 vehicles<br>
About 170 new items in total<br>

<b>v6.2 Update</b><br>
Added BREAKING POINT Mod - thanks to CHAINSAW SQUIRREL<br>

<br>
NOTE RHS IS BOTH RUS AND USA.<br>
<br><br>
<b>***************************************************</b><br>
<b>****** Thanks to all the following for help 	******</b><br>
<b>****** XxFri3ndlyxX, [RG] Salutesh, SE7EN	******</b><br>
<b>****** Tobias Solem, pomp4h, Bob_the_K, ItsDutch ******</b><br>
<b>****** Razor77, jmayr2000, C][G GhostTown�	******</b><br>
<b>****** ElShotte, Killerpoodezz, CHAINSAW SQUIRREL	******</b><br>
<b>***************************************************</b><br>
<br><br>
<b>Big thanks to Exile Mod <a href="http://www.exilemod.com">http://www.exilemod.com</a></b><br>
<br>
<b>Orignal thread and support at <a href="http://www.exilemod.com/topic/8586-updated-easy-trader-set-up">http://www.exilemod.com/topic/8586-updated-easy-trader-set-up</a></b><br>