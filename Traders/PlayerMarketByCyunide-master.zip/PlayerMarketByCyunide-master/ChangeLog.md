# Version 1.1

* Added the ability to customize the mod and set restrictions. You can do so inside the @ExileServer\addons\PlayerMarketByCyunide\customize.sqf
* Improved performance and checks to make sure items appear.
* Few minor bug fixes

# Version 1.0

Initial version.
