# Update Instuctions

### Upgrading to 1.1 From 1.0

* Overwrite @ExileServer\addons\PlayerMarketByCyunide.pbo with the one from the download.
* Modify exile.ini to add the 2 new database calls. (Or just totally copy/paste over the old edits)
* In your Exile.Altis (Or mission) folder overwrite Functions/ExileClient_system_transport_network_listPlayerMarketResponse.sqf with the one from the download.
* Make sure you repack the pbos!

