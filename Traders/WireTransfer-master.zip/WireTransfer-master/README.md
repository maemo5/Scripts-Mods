# WireTransfer
Allows for players to send money directly to another online players bank from their own wallet/bank. Default interaction point is at the lockers in any safezone, but that can be easily changed in config.cpp

Installation
- Simply drop the KBC folder into your mission root.
- Ammend your files with the ones provided.
- Note: If you drop the KBC folder somewhere besides mission root, be sure to change all of the paths that lead to certain files.
- Note: Some people already have a CfgNetworkMessages in description.ext rather than config.cpp. If this is the case, ammend this portion to description.ext not config.cpp

GUI Preview:
https://gyazo.com/5adab9f5e785a9105d0411d979ae0311
