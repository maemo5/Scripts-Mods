///////////////////////////////////////////////////////////////////////////////

Installation:
1. Backup your "Exile.Tanoa.pbo file"

2. Copy files from mpmissions folder into you Tanoa mission file and overwrite

3. Repack Mission file. U have succefully installed Tanoa Silver
	
	Note. All files are tested on a clean server with no additional mods. 
	If something breaks restore from your backups make in step 1
	
///////////////////////////////////////////////////////////////////////////////