class SA
{
	class AdvancedRappelling
	{
		file = "addons\AR_AdvancedRappelling\functions";
		class advancedRappellingInit { postInit = 1; };
	};
};