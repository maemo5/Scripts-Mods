# Exile Occupation (a3_exile_occupation)

![v70 New Features](https://img.shields.io/badge/v70-New%20Features-red.svg) ![Arma 1.84](https://img.shields.io/badge/Arma-1.84-blue.svg) ![Exile 1.0.4 Pineapple](https://img.shields.io/badge/Exile-1.0.4%20Pineapple-C72651.svg) 

WTF is Occupation?
An AI spawner and monitor to be used in conjunction with DMS and will not work without it:
http://www.exilemod.com/topic/61-dms-defents-mission-system/

How to install?
To install place the pbo into the @ExileServer/addons folder

How edit and compile?
You'll find the files in the source folder. Edit the config as you need and then compile the PBO with PBO Manager 1.4b:
http://www.armaholic.com/page.php?id=16369 - (Please note, only use the x64 version)

For more info:
http://www.exilemod.com/topic/12517-release-exile-occupation-roaming-ai

## License Overview:
This work is protected by [Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0)](http://creativecommons.org/licenses/by-nc-sa/4.0/). By using, downloading, or copying any of the work contained, you agree to the license included.

<a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-sa/4.0/88x31.png" /></a><br /><span xmlns:dct="http://purl.org/dc/terms/" href="http://purl.org/dc/dcmitype/Text" property="dct:title" rel="dct:type">Exile Occupation</span> by <a xmlns:cc="http://creativecommons.org/ns#" href="https://github.com/secondcoming/a3_exile_occupation" property="cc:attributionName" rel="cc:attributionURL">second_coming</a> is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/">Creative Commons Attribution-ShareAlike 4.0 International License</a>.

## Donations:
Anyone wishing to donate can do so here http://exileyorkshire.co.uk/
All donations go towards coffee to keep me awake :)

### Updated and modified by [FPS]kuplion, plus a number of community fixes.