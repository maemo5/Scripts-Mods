Sheeps Exile Repack - ExPack 0.01 "Fresh Jeans"
=============

Pre release of ExPack. 

> YOU CAN NOT REUSE THE SCRIPTS/ADDONS IN THIS REPACK WITH OUT THE SCRIPT OWNERS PERMISSION

Current Supported Maps
--------------------------
* Altis
* Bornholm
* Chernarus 
* Al Rayak
* Sahrani
* Esseker

Current Scripts
--------------------------
* Kill Messages by [`GR8`](http://www.exilemod.com/profile/64-gr8/)
* Welcome Credits by [`GR8`](http://www.exilemod.com/profile/64-gr8/)
* Watermark Logo by MadHatter05
* ExileIgiLoad with TaruPodMod by [`SLB2k11`](http://www.exilemod.com/profile/409-slb2k11/)
* Dynamic Vehicle Spawn with Items by [`Jenartor`](http://www.exilemod.com/profile/53934-jenartor/)
* Detrimental Weather Effects by [`John`](http://www.exilemod.com/profile/38-john/)
* Dynamic Air Patrol by [`John`](http://www.exilemod.com/profile/38-john/)
* Shix's XM8 apps by [`Shix`](http://www.exilemod.com/profile/4566-shix/)
* Exile_VEMF_Reloaded by [`IT07`](http://www.exilemod.com/profile/332-it07/)
* Random Heli Crashes by [`Darth_Rouge`](http://www.exilemod.com/profile/3705-darth_rogue/)
* Slot Machine by [`Fallingsheep`] (http://www.exilemod.com/profile/59883-fallingsheep/)
* Creepy Night Fog by CNSU
* Update Respect/Poptabs and save to database by [`happydayz`](http://www.exilemod.com/profile/3076-happydayz/)
* W4rGo's Lockpick System by [`W4rGo`](http://www.exilemod.com/profile/3342-w4rgo/)
* EMP Blowout from Namalsk
* Blackjack Orginal script by papabear modified by [`Fallingsheep`] (http://www.exilemod.com/profile/59883-fallingsheep/) for Exile [`Original Atlis Life Script`](http://www.altisliferpg.com/topic/7532-howto-blackjackreal/)
* Dynamic Electrical Storms by [`John`](http://www.exilemod.com/profile/38-john/)
* ETG Heli Crash and Drop Script by [`Kellojo`] (http://www.exilemod.com/profile/3541-kellojo/)
* Chop wood directly into a truck by  [`Phate`] (http://www.exilemod.com/profile/40698-phate/)
* DMS - Defents Mission System by [`Defent`](http://www.exilemod.com/profile/259-defent/) & [`eraser1`](http://www.exilemod.com/profile/96-eraser1/)
* AVS - Advanced Vehicle System by [`Rod Serling`](http://www.exilemod.com/profile/20-rod-serling/)
* Deploy bike [`StokesMagee`](http://www.exilemod.com/profile/49712-stokesmagee/)
* Pack bike [`Austin`](http://www.exilemod.com/profile/41-austin/)
* ScrapBike by [`Taylor Swift (Mezo)`](http://www.exilemod.com/profile/472-taylor-swift-mezo/)
* GPS Check for Map Markers by [`Wyqer`](http://www.exilemod.com/profile/52393-wyqer/)
* Indestructible Bases
* Respect Based Load Outs

Script Permission List
--------------------------
* [`GR8`](http://www.exilemod.com/profile/64-gr8/)
* [`Jenartor`](http://www.exilemod.com/profile/53934-jenartor/)
* [`John`](http://www.exilemod.com/profile/38-john/)
* [`Taylor Swift (Mezo)`](http://www.exilemod.com/profile/472-taylor-swift-mezo/)
* [`Darth_Rouge`](http://www.exilemod.com/profile/3705-darth_rogue/)
* [`Defent`](http://www.exilemod.com/profile/259-defent/)
* [`Wyqer`](http://www.exilemod.com/profile/52393-wyqer/)
* [`Shix`](http://www.exilemod.com/profile/4566-shix/)
* [`IT07`](http://www.exilemod.com/profile/332-it07/)
* [`eraser1`](http://www.exilemod.com/profile/96-eraser1/)
* [`infiSTAR`](http://www.exilemod.com/profile/11-infistar/) - BE Filters
* [`happydayz`](http://www.exilemod.com/profile/3076-happydayz/)
* [`Kellojo`] (http://www.exilemod.com/profile/3541-kellojo/)

Scripts to be added 
--------------------------
* Roaming Traders by [`John`](http://www.exilemod.com/profile/38-john/)
* Respect Ranking System
* Achievement System
* ETG Login Reward Script by [`Kellojo`] (http://www.exilemod.com/profile/3541-kellojo/)

