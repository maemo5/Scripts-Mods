class VEMF_Reloaded
{
    tag = "VEMFr";
    class clientFunctions
    {
        file = "VEMFr_client\functions";
        class handleMessage {};
        class clientInit { postInit = 1; };
    };
};
