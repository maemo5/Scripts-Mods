- # Installation instructions :

- delete all WY Snow classes added to mission/config.cpp first..
- Add folder Custom/TraderAdditions to mission folder.
- OPEN traderConfig.hpp and apply changes required to mission/config.cpp
- now open WY_PriceList.hpp and WY_TraderCategories.hpp setup what you want.
