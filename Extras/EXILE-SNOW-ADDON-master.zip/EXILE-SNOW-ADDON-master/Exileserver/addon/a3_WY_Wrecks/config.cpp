class CfgPatches {
	class RSZ {
		units[] = {};
		weapons[] = {};
		requiredVersion = 1.36;
		requiredAddons[] = {};
	};
};

class CfgFunctions {
	class RSZF {
		class WYWrecks {
			file = "x\addons\a3_WY_Wrecks";
			class init {
				preInit = 1;
			};
		};
	};
};
