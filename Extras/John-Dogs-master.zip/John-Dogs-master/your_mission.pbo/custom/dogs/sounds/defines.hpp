
	class bark2
    {
        name = "bark2";
        sound[] = {"custom\dogs\sounds\bark2.ogg",1.0,1.0};
        titles[] = {};
    };
	class barkmean1
    {
        name = "barkmean1";
        sound[] = {"custom\dogs\sounds\barkmean1.ogg",1.0,1.0};
        titles[] = {};
    };
	class dog_growl
    {
        name = "dog_growl";
        sound[] = {"custom\dogs\sounds\dog_growl.ogg",1.0,1.0};
        titles[] = {};
    };
    class dog_ruff
    {
        name = "dog_ruff";
        sound[] = {"custom\dogs\sounds\dog_ruff.ogg",1.0,1.0};
        titles[] = {};
    };
    class dog_whine
    {
        name = "dog_whine";
        sound[] = {"custom\dogs\sounds\dog_whine.ogg",1.0,1.0};
        titles[] = {};
    };
	class growls3
    {
        name = "growls3";
        sound[] = {"custom\dogs\sounds\growls3.ogg",1.0,1.0};
        titles[] = {};
    };
	class pain
    {
        name = "pain";
        sound[] = {"custom\dogs\sounds\pain.ogg",1.0,1.0};
        titles[] = {};
    };
    class whistle
    {
        name = "whistle";
        sound[] = {"custom\dogs\sounds\whistle.ogg",1.0,1.0};
        titles[] = {};
    };

