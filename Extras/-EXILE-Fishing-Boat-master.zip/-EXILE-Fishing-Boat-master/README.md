/////////////////////////////// ////////// Exile mod 1.0.4 'Pineapple' Compatible ////////// ///////////////////////////////

Basic fishing script for exile by JackFrost 

modify by Serveratze [Fishing Boat]

---------------------------------------------------------------------------------

Step 1

Copy the Folder custom to you Exile.YourMap Folder

---------------------------------------------------------------------------------

Step 2

Copy the Folder overrides to you Exile.YourMap Folder

in the Config.cpp in the ection CfgExileCustomCode you Add:

ExileClient_gui_hud_event_onKeyUp = "overrides\ExileClient_gui_hud_event_onKeyUp.sqf";

---------------------------------------------------------------------------------

Use shift key right for Fishing!

---------------------------------------------------------------------------------

Have Fun with this Modification :)
